import discord
from discord.ext import commands
import os

# ===== INTENTS =====
intents = discord.Intents.default()
intents.message_content = True
intents.members = True


# ===== BOT CLASS =====
class MyBot(commands.Bot):
    async def setup_hook(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))

        for folder in ["commands", "events"]:
            path = os.path.join(base_dir, folder)

            if not os.path.exists(path):
                print(f"⚠ Pasta não encontrada: {path}")
                continue

            for file in os.listdir(path):
                if file.endswith(".py"):
                    try:
                        await self.load_extension(f"{folder}.{file[:-3]}")
                        print(f"✅ Carregado: {folder}.{file[:-3]}")
                    except Exception as e:
                        print(f"❌ Erro ao carregar {file}: {e}")

        await self.tree.sync()
        print("✅ Slash commands sincronizados!")


# ===== BOT INSTANCE =====
bot = MyBot(command_prefix="/", intents=intents, help_command=None)


# ===== READY =====
@bot.event
async def on_ready():
    print(f"🚀 Logado como {bot.user}")


# ===== RUN =====
bot.run("MTQ2MDczNjgzNjAyMzM1NzUwMw.GSzVcb.aDruo3MXssuX1dDdxaApGr_B26ff2faMboFows")

import discord


async def send_log(guild: discord.Guild, embed: discord.Embed):
    channel = discord.utils.get(guild.text_channels, name="logs")

    if not channel:
        return

    await channel.send(embed=embed)

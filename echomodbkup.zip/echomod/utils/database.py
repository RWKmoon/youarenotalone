import sqlite3

conn = sqlite3.connect("database.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS config (
    guild_id INTEGER PRIMARY KEY,
    log_channel INTEGER
)
""")
conn.commit()


def set_log_channel(guild_id, channel_id):
    cursor.execute(
        "INSERT OR REPLACE INTO config (guild_id, log_channel) VALUES (?, ?)",
        (guild_id, channel_id)
    )
    conn.commit()


def get_log_channel(guild_id):
    cursor.execute(
        "SELECT log_channel FROM config WHERE guild_id = ?",
        (guild_id,)
    )
    row = cursor.fetchone()
    return row[0] if row else None

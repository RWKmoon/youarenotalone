import discord
from discord.ext import commands
from discord import app_commands
from utils.perms import has_staff_perm
from utils.database import set_log_channel

class Config(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="setlog", description="Define o canal de logs")
    async def setlog(self, interaction: discord.Interaction, channel: discord.TextChannel):
        if not await has_staff_perm(interaction):
            return

        set_log_channel(interaction.guild.id, channel.id)

        await interaction.response.send_message(
            f"✅ Canal de logs definido como {channel.mention}",
            ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(Config(bot))

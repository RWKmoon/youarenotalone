import discord, asyncio
from discord.ext import commands

class Util(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="clear", description="Deleta mensagens")
    async def clear(self, interaction: discord.Interaction, n: int = 100):
        await interaction.channel.purge(limit=n+1)
        msg = await interaction.channel.send(f"{n} mensagens apagadas.")
        await asyncio.sleep(5)
        await msg.delete()

    @discord.app_commands.command(name="svinfo", description="Info do servidor")
    async def svinfo(self, interaction: discord.Interaction):
        g = interaction.guild
        await interaction.response.send_message(f"Membros: {g.member_count}")

    @discord.app_commands.command(name="userinfo", description="Info usuário")
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        await interaction.response.send_message(f"Usuário: {member.name}")

    @discord.app_commands.command(name="nuke", description="Reseta canal")
    async def nuke(self, interaction: discord.Interaction):
        canal = interaction.channel
        clone = await canal.clone()
        await canal.delete()
        await clone.send("Canal resetado.")


async def setup(bot):
    await bot.add_cog(Util(bot))
